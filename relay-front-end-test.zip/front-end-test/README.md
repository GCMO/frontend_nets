To get started, run:

```
yarn install or npm i
```

and then:

```
yarn dev or npm run dev
```
